/*
*Author: Timothy Khan (1239165)
*Project 2
*
*The purpose of the program is to take a user inputted
*file containing locations with respect to the user and 
*determine who is closest to the user.
*
*/

#include <stdio.h>
#include <string.h>
#include <math.h>


// define group of variables in structures
struct position{
  double altitude;
  double longitude;
  double latitude;
}; typedef struct position position;

struct user_t{
  char name[50];
  double time;
  position position;
}; typedef struct user_t user_t;

struct distance{
  char name[50];
  double distance_from_user;
}; typedef struct distance distance;

// prototypes so ordering of functions doesnt affect functionality
void search_distance(distance x[],int b);
void calculating_distance (user_t x, user_t y[], int num);
void scan_user(char fileName []);


// read user file
void scan_user(char fileName []){
  int num = 0;
  FILE* file;
  user_t our_user;
  char textInput [150];

  file = fopen (fileName, "r");

  if (NULL == file) {
    printf ("failed: file could not be opened \n");
  }
  fgets (textInput, 150, file);
  sscanf (textInput, "%d", &num);

  user_t other_user[num];

  int counter = 0;
  int i = -1;

  while(!feof(file)){
    fscanf(file, "%s", textInput);
    double alt = 0.0;
    double longt = 0.0;
    double t = 0.0;
    double lat = 0.0;

// save data for our user
    if (i == -1){
        switch(counter){
        case 0:
            strcpy (our_user.name, textInput);
            counter += 1;
            break;
        case 1:
            sscanf (textInput, "%lf" , &t);
            our_user.time = t;
            counter += 1;
            break;
        case 2:
            sscanf(textInput, "%lf", &lat);
            our_user.position.latitude = lat;
            counter += 1;
            break;
        case 3:
            sscanf (textInput, "%lf", &longt);
            our_user.position.longitude = longt;
            counter += 1;
            break;
        case 4:
            sscanf (textInput, "%lf", &alt);
            our_user.position.altitude = alt;
            counter = 0;
            i += 1;
            break;
        }
// save data for other people
    }
    else {
        switch(counter){
        case 0:
            strcpy (other_user[i].name, textInput);
            counter += 1;
            break;
        case 1:
            sscanf (textInput, "%lf" , &t);
            other_user[i].time = t;
            counter += 1;
            t = 0;
            break;
        case 2:
            sscanf(textInput, "%lf", &lat);
            other_user[i].position.latitude = lat;
            counter += 1;
            lat = 0;
            break;
        case 3:
            sscanf (textInput, "%lf", &longt);
            other_user[i].position.longitude = longt;
            counter += 1;
            break;
        case 4:
            sscanf (textInput, "%lf", &alt);
            other_user[i].position.altitude = alt;
            counter = 0;
            i += 1;
            break;
        }
    }
  }
  fclose (file);
  calculating_distance(our_user, other_user, num);
 }

// compare distance between our user and each person
void search_distance(distance x[],int b){
  int index = 0;
  int g = 1;
  int p = x[g].distance_from_user;
  int i = 0;
  int q;

  for (int i = 0; i != b; i ++){
    int c = x[i+1].distance_from_user;
    if (p < c){
    break;
    }
    else{
    q = i + 1;
    p = x[q].distance_from_user;
    }
  }
  printf("The person closest to the user is %s. They are %lf metres away.", x[q].name, x[q].distance_from_user);
}

// calculate the distance between user and each person

void calculating_distance (user_t x, user_t y[], int num){

  double xx = x.position.latitude;    
  double xy = x.position.longitude;    
  double xz = x.position.altitude;   
  distance d[num];
  double yy, yx, yz;

  for (int i = 0; i != num; i ++){
    yx = y[i].position.latitude;
    yy = y[i].position.longitude;
    yz = y[i].position.altitude;
    strcpy(d[i].name, y[i].name);
    d[i].distance_from_user = sqrt(((xx - yx) * (xx - yx)) + ((xy - yy) * (xy - yy)) + ((xz - yz) * (xz - yz)));
    printf("%s\n%lf\n", d[i].name, d[i].distance_from_user);
  }
  search_distance(d, num);
}

// run functions and execute code
int main(){
    char fileName[150];
    printf ("Enter the file name: ");
    scanf ("%[^\n]", fileName);
    scan_user (fileName);
    return 0;
}