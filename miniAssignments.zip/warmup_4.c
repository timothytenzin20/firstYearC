// Implement a function that takes an integer n as a parameter and calculates and returns the sum of all
// divisors of n. For example, if n = 6 then this function must return 12
int sum(n);

void main (){
    int num;
    printf ("Enter an integer: ");
    scanf ("%d", &num);
    sum(num);
}

int sum (int n){
int total = 0;

	for(int i = 1; i <= n; i++) {
		if((n%i) == 0){
            total += i;
		}
	}

printf ("The total of all the divisors of %d is %d\n", n, total);

}